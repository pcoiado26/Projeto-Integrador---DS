package com.example.myapi.controller;

import com.example.myapi.model.Funcionario;
import com.example.myapi.service.FuncionarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/funcionarios")
public class FuncionarioController {

    @Autowired
    private FuncionarioService funcionarioService;

    @GetMapping
    public List<Funcionario> getAllFuncionarios() {
        return funcionarioService.getAllFuncionarios();
    }

    @GetMapping("/{id}")
    public Funcionario getFuncionarioById(@PathVariable Long id) {
        return funcionarioService.getFuncionarioById(id);
    }

    @PostMapping
    public Funcionario createFuncionario(@RequestBody Funcionario funcionario) {
        return funcionarioService.saveFuncionario(funcionario);
    }

    @PutMapping("/{id}")
    public Funcionario updateFuncionario(@PathVariable Long id, @RequestBody Funcionario funcionarioDetails) {
        Funcionario funcionario = funcionarioService.getFuncionarioById(id);

        if (funcionario != null) {
            funcionario.setFuncao(funcionarioDetails.getFuncao());
            funcionario.setCpf(funcionarioDetails.getCpf());
            funcionario.setNomeLogin(funcionarioDetails.getNomeLogin());
            funcionario.setSenha(funcionarioDetails.getSenha());
            funcionario.setDataNascimento(funcionarioDetails.getDataNascimento());
            funcionario.setNome(funcionarioDetails.getNome());
            funcionario.setEmail(funcionarioDetails.getEmail());
            return funcionarioService.saveFuncionario(funcionario);
        }

        return null;
    }

    @DeleteMapping("/{id}")
    public void deleteFuncionario(@PathVariable Long id) {
        funcionarioService.deleteFuncionario(id);
    }
}
